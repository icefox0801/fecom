# comp_sub_a
A magic component
