# comp_sub_b
A magic component
