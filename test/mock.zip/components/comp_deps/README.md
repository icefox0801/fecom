# comp_deps
A magic component
