# comp_valid_version
A magic component
